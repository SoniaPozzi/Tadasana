function varargout = PostureApp(varargin)
% POSTUREAPP MATLAB code for PostureApp.fig
%      POSTUREAPP, by itself, creates a new POSTUREAPP or raises the existing
%      singleton*.
%
%      H = POSTUREAPP returns the handle to a new POSTUREAPP or the handle to
%      the existing singleton*.
%
%      POSTUREAPP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in POSTUREAPP.M with the given input arguments.
%
%      POSTUREAPP('Property','Value',...) creates a new POSTUREAPP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PostureApp_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PostureApp_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PostureApp

% Last Modified by GUIDE v2.5 29-Apr-2018 14:23:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PostureApp_OpeningFcn, ...
                   'gui_OutputFcn',  @PostureApp_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PostureApp is made visible.
function PostureApp_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PostureApp (see VARARGIN)
global s;
global B;
global correct_values;
global wrong_values;
global count_correct;
global count_wrong;
global isMonitoring;
isMonitoring = false;

correct_values = zeros(10,5);
wrong_values = zeros(10,5);
count_correct = 0;
count_wrong = 0;

try
    B = Bluetooth('HC-05', 1);
    
    %s = serial('COM6');
    %s.Baudrate = 9600;
    %s.Terminator = 'LF';
    %s.InputBufferSize = 200; % read only one byte every time
    fopen(B);
    doBeep();
catch err
    fclose(B);
    error('Make sure you select the correct COM Port where the Arduino is connected.');
end

% Choose default command line output for PostureApp
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PostureApp wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PostureApp_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function v = getValues()
    global B;
    %flushinput(B);
    pause(0.1);
    N_sensors = 5;
    v = zeros(1,N_sensors);
    str = [];
    while(isempty(str))
        try
            fprintf(B, 'R');
            str = fgetl(B);
        catch
            str = [];
        end
    end

    if(~isempty(str))
        if( ((str(1) == 13) && numel(str > 3)))
            str = str(2:end);
        end
        if( ((str(end) == 13) && numel(str > 1)))
            str = str(1:end-1);
        end
        sensor_strs = split(str, ';');
        for ii = 1:size(sensor_strs, 1)
            if(~isempty(str2num(sensor_strs{ii})))
                v(ii) = str2num(sensor_strs{ii});
            end
        end
    end
    
function doBeep()
    global B
    fprintf(B, 'B');


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global count_wrong;
global wrong_values;
disp 'wrong position';
sensors_values = getValues()
if nnz(sensors_values) == 5
    count_wrong = count_wrong+1;
    wrong_values(count_wrong,:) = sensors_values;
    doBeep();
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
disp 'correct position';
global count_correct;
global correct_values;
sensors_values = getValues()
if nnz(sensors_values) == 5
    count_correct = count_correct+1;
    correct_values(count_correct,:) = sensors_values;
    doBeep();
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global s;
try
fclose(s);
catch
    disp 'error';
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
doBeep();


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
disp 'test position';

load 't3.mat';
x = getValues();
U = w'*x'-g';
if(U > 0.5)
    disp 'CORRECT posture';
else
    disp 'WRONG posture';
end
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global isMonitoring;
isMonitoring = false;


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
global isMonitoring
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(~isMonitoring)
    isMonitoring = true;
end
load 't3.mat';
while(isMonitoring)
    x = getValues();
    U = w'*x'-g';
    if(U > 0.5)
        disp 'CORRECT posture';
    else
        disp 'WRONG posture';
    end
    pause(2);
end
